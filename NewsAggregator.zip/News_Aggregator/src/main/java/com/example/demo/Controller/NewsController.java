package com.example.demo.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.example.demo.Service.NewsService;
import com.example.demo.model.NewsArticle;

import java.util.List;

@Controller
@RequestMapping("/news")
public class NewsController {

    @Autowired
    private NewsService newsService;

    // Show news by category and country
    @GetMapping
    public String getNews(
            @RequestParam(required = false, defaultValue = "general") String category,
            @RequestParam(required = false, defaultValue = "us") String country,
            Model model) {
        
        List<NewsArticle> newsList = newsService.getNews(category, country);
        model.addAttribute("newsList", newsList);
        model.addAttribute("category", category);
        model.addAttribute("country", country);
        
        return "news"; // Render news.html with news data
    }
    @GetMapping("/news")
    public String getFilteredNews(@RequestParam String category, @RequestParam String country, Model model) {
        List<NewsArticle> filteredNews = newsService.getFilteredNews(category, country);
        model.addAttribute("newsList", filteredNews);
        return "news"; // This refers to your HTML file
}
}