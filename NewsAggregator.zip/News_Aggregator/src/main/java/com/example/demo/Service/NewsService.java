package com.example.demo.Service;



import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.function.EntityResponse;

import com.example.demo.model.NewsArticle;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

@Service
public class NewsService {

    @Value("${newsapi.api.key}")
    private String apiKey;

    private final String API_URL = "https://newsapi.org/v2/top-headlines";

    public List<NewsArticle> getNews(String category, String country) {
        String url = API_URL + "?category=" + category + "&country=" + country + "&apiKey=" + apiKey;

        RestTemplate restTemplate = new RestTemplate();
        String response = restTemplate.getForObject(url, String.class);

        List<NewsArticle> articles = new ArrayList<>();
        JSONObject jsonResponse = new JSONObject(response);
        JSONArray jsonArticles = jsonResponse.getJSONArray("articles");

        for (int i = 0; i < jsonArticles.length(); i++) {
            JSONObject obj = jsonArticles.getJSONObject(i);
            NewsArticle article = new NewsArticle();
            article.setTitle(obj.getString("title"));
            article.setDescription(obj.optString("description"));
            article.setUrl(obj.getString("url"));
            article.setSource(obj.getJSONObject("source").getString("name"));

            articles.add(article);
        }

        return articles;
    }

	public List<NewsArticle> getAllNews() {
		// TODO Auto-generated method stub
		return null;
	}

	public NewsArticle getNewsById(Long id) {
		// TODO Auto-generated method stub
		return null;
	}
	public List<NewsArticle> getFilteredNews(String category, String country) {
        // Construct the API URL using the category and country parameters
        String apiUrl = "https://newsapi.org/v2/top-headlines?category=" + category + "&country=" + country + "&apiKey=YOUR_API_KEY";
        
        // Make the GET request to the news API
        ResponseEntity<NewsApiResponse> response = new ResponseEntity<NewsApiResponse>(null);
        
        // Return the list of news articles
        return response.getBody().getArticles();
    }
}